import os
import shutil
import logging

def setup_logging(target_directory):
    """Sets up a log file inside the folder being organized."""
    log_file_path = os.path.join(target_directory, "automation_log.txt")
    
    # Configure logging to write to both a file and the console
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file_path),
            logging.StreamHandler()
        ]
    )

def organize_folder():
    print("--- File Organizer Automation Tool ---")
    
    # 1. ADD USER INPUT SUPPORT & EXCEPTION HANDLING FOR PATH
    user_path = input("Enter the absolute path of the folder to organize: ").strip()
    
    if not os.path.exists(user_path):
        print(f"Error: The path '{user_path}' does not exist. Please run the script again with a valid path.")
        return
        
    if not os.path.isdir(user_path):
        print(f"Error: The path '{user_path}' is a file, not a folder.")
        return

    # Initialize the logger
    setup_logging(user_path)
    logging.info(f"Starting file organization in: {user_path}")

    # Define common file categories and their extensions
    file_categories = {
        "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp"],
        "Documents": [".pdf", ".docx", ".doc", ".txt", ".xlsx", ".pptx"],
        "Videos": [".mp4", ".mkv", ".avi", ".mov"],
        "Audio": [".mp3", ".wav", ".aac"],
        "Archives": [".zip", ".rar", ".7z", ".tar"]
    }

    try:
        # 2. USE OS MODULE TO LIST ALL FILES
        for item in os.listdir(user_path):
            item_path = os.path.join(user_path, item)
            
            # Skip directories, the log file itself, and hidden files
            if os.path.isdir(item_path) or item == "automation_log.txt" or item.startswith('.'):
                continue
                
            # Get the file extension (e.g., '.jpg')
            _, extension = os.path.splitext(item)
            extension = extension.lower()
            
            # Find the correct category folder name
            moved = False
            for category, extensions in file_categories.items():
                if extension in extensions:
                    category_folder = os.path.join(user_path, category)
                    
                    # Create the subfolder if it doesn't exist yet
                    if not os.path.exists(category_folder):
                        os.makedirs(category_folder)
                        logging.info(f"Created category folder: {category}")
                    
                    # Move the file
                    shutil.move(item_path, os.path.join(category_folder, item))
                    # 3. GENERATE LOGS FOR OPERATIONS
                    logging.info(f"Moved: '{item}' -> Folder: [{category}]")
                    moved = True
                    break
            
            # If the file extension doesn't match any category, move to an 'Others' folder
            if not moved:
                others_folder = os.path.join(user_path, "Others")
                if not os.path.exists(others_folder):
                    os.makedirs(others_folder)
                shutil.move(item_path, os.path.join(others_folder, item))
                logging.info(f"Moved unknown file: '{item}' -> Folder: [Others]")

        logging.info("Folder organization completed successfully!")
        print("\n🎉 Success! Check 'automation_log.txt' inside your target folder for the detailed log.")

    # 1. EXCEPTION HANDLING FOR SYSTEM/PERMISSION ERRORS
    except PermissionError:
        logging.error("Permission denied: Could not read files or create folders. Try running as administrator.")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    organize_folder()